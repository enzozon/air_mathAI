"""
Interface gráfica do Air Math AI (CustomTkinter).

Exibe o vídeo da webcam com o canvas sobreposto, o gesto detectado, a
expressão reconhecida, o resultado e os passos da resolução. Oferece botões
para treinar/carregar modelo, coletar amostras para o dataset e ajustar
parâmetros básicos.

A atualização do vídeo usa o laço de eventos do Tkinter (``after``), evitando
condições de corrida com a UI. O treinamento roda em uma thread separada para
não congelar a interface.
"""
from __future__ import annotations

import threading
import tkinter as tk
from typing import Optional

import cv2

try:
    import customtkinter as ctk
    from PIL import Image
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "A interface gráfica requer 'customtkinter' e 'Pillow'. "
        "Instale com: pip install customtkinter pillow"
    ) from exc

from config import AppConfig, CLASS_LABELS, CLASS_NAMES
from src.dataset.dataset_manager import DatasetManager
from src.engine import AirMathEngine
from src.gestures.gesture_recognizer import Gesture
from src.utils.logger import get_logger

logger = get_logger(__name__)

_GESTURE_LABELS = {
    Gesture.NONE: "— nenhum —",
    Gesture.MOVE: "👆 Mover",
    Gesture.DRAW: "✌️ Desenhar",
    Gesture.CLEAR: "🖐️ Limpar (3)",
    Gesture.CAPTURE: "✋ Reconhecer (4)",
    Gesture.QUIT: "🖐️ Sair (5)",
}


class AirMathApp(ctk.CTk):
    """Janela principal da aplicação."""

    def __init__(self, config: AppConfig) -> None:
        super().__init__()
        self._config = config
        self._engine = AirMathEngine(config)
        self._dataset = DatasetManager()
        self._running = False
        self._photo: Optional[ctk.CTkImage] = None

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.title("Air Math AI")
        self.geometry("1180x760")
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self._build_layout()
        self._start_engine()

    # ------------------------------------------------------------------
    # Construção da UI
    # ------------------------------------------------------------------
    def _build_layout(self) -> None:
        """Monta os widgets da janela."""
        self.grid_columnconfigure(0, weight=3)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # --- Painel do vídeo ---
        video_frame = ctk.CTkFrame(self)
        video_frame.grid(row=0, column=0, padx=12, pady=12, sticky="nsew")
        video_frame.grid_rowconfigure(0, weight=1)
        video_frame.grid_columnconfigure(0, weight=1)

        self._video_label = ctk.CTkLabel(video_frame, text="Iniciando webcam...")
        self._video_label.grid(row=0, column=0, sticky="nsew")

        # --- Painel lateral de controles ---
        side = ctk.CTkScrollableFrame(self, label_text="Air Math AI")
        side.grid(row=0, column=1, padx=12, pady=12, sticky="nsew")

        self._gesture_var = tk.StringVar(value="— nenhum —")
        self._expr_var = tk.StringVar(value="—")
        self._result_var = tk.StringVar(value="—")

        ctk.CTkLabel(side, text="Gesto detectado", font=("", 13, "bold")).pack(
            anchor="w", pady=(6, 0)
        )
        ctk.CTkLabel(side, textvariable=self._gesture_var, font=("", 18)).pack(
            anchor="w", pady=(0, 10)
        )

        ctk.CTkLabel(side, text="Expressão reconhecida", font=("", 13, "bold")).pack(
            anchor="w"
        )
        ctk.CTkLabel(side, textvariable=self._expr_var, font=("", 20)).pack(
            anchor="w", pady=(0, 6)
        )

        ctk.CTkLabel(side, text="Resultado", font=("", 13, "bold")).pack(anchor="w")
        ctk.CTkLabel(
            side, textvariable=self._result_var, font=("", 26, "bold"),
            text_color="#33d17a",
        ).pack(anchor="w", pady=(0, 10))

        self._steps_box = ctk.CTkTextbox(side, height=120)
        self._steps_box.pack(fill="x", pady=(0, 12))
        self._steps_box.insert("1.0", "Os passos da resolução aparecerão aqui.")
        self._steps_box.configure(state="disabled")

        # Botões de ação
        ctk.CTkButton(side, text="🔍 Reconhecer agora", command=self._recognize).pack(
            fill="x", pady=4
        )
        ctk.CTkButton(side, text="🧹 Limpar canvas", command=self._clear).pack(
            fill="x", pady=4
        )

        ctk.CTkLabel(side, text="Modelo", font=("", 13, "bold")).pack(
            anchor="w", pady=(12, 0)
        )
        ctk.CTkButton(side, text="📂 Carregar modelo", command=self._load_model).pack(
            fill="x", pady=4
        )
        self._train_btn = ctk.CTkButton(
            side, text="🧠 Treinar modelo", command=self._train_model
        )
        self._train_btn.pack(fill="x", pady=4)
        self._model_status = ctk.CTkLabel(side, text="", font=("", 11))
        self._model_status.pack(anchor="w", pady=(0, 8))

        # Coleta de dataset
        ctk.CTkLabel(side, text="Coletar amostra (dataset)", font=("", 13, "bold")).pack(
            anchor="w", pady=(8, 0)
        )
        self._label_var = tk.StringVar(value=CLASS_NAMES[0])
        options = [f"{c}  ({CLASS_LABELS[c]})" for c in CLASS_NAMES]
        self._label_menu = ctk.CTkOptionMenu(
            side, values=options, command=self._on_label_change
        )
        self._label_menu.pack(fill="x", pady=4)
        ctk.CTkButton(side, text="💾 Salvar amostra", command=self._save_sample).pack(
            fill="x", pady=4
        )
        self._dataset_status = ctk.CTkLabel(side, text="", font=("", 11))
        self._dataset_status.pack(anchor="w", pady=(0, 8))

        # Configurações
        ctk.CTkLabel(side, text="Espessura do pincel", font=("", 13, "bold")).pack(
            anchor="w", pady=(8, 0)
        )
        self._thickness = ctk.CTkSlider(
            side, from_=4, to=30, number_of_steps=26, command=self._on_thickness
        )
        self._thickness.set(self._config.canvas.brush_thickness)
        self._thickness.pack(fill="x", pady=4)

        ctk.CTkButton(
            side, text="❌ Sair", fg_color="#a01818", hover_color="#7a1010",
            command=self._on_close,
        ).pack(fill="x", pady=(12, 4))

        self._update_model_status()

    # ------------------------------------------------------------------
    # Ciclo do engine
    # ------------------------------------------------------------------
    def _start_engine(self) -> None:
        """Inicia o engine e o laço de atualização de frames."""
        try:
            self._engine.start()
            self._running = True
            self._update_frame()
        except Exception as exc:  # noqa: BLE001
            logger.error("Falha ao iniciar a webcam: %s", exc)
            self._video_label.configure(text=f"Erro ao abrir a webcam:\n{exc}")

    def _update_frame(self) -> None:
        """Processa e exibe um frame; reprograma a si mesmo."""
        if not self._running:
            return
        try:
            result = self._engine.process_frame()
            self._render_frame(result.frame)
            self._gesture_var.set(_GESTURE_LABELS.get(result.gesture, "—"))

            if result.recognition is not None:
                self._show_recognition(result.recognition)
            if result.action == Gesture.QUIT:
                self._on_close()
                return
        except Exception as exc:  # noqa: BLE001
            logger.error("Erro no loop de vídeo: %s", exc)

        self.after(15, self._update_frame)

    def _render_frame(self, frame_bgr) -> None:
        """Converte o frame BGR para exibição no label."""
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(rgb)
        # Ajusta ao tamanho do label preservando a proporção aproximada.
        target_w = max(self._video_label.winfo_width(), 640)
        ratio = target_w / img.width
        size = (target_w, int(img.height * ratio))
        self._photo = ctk.CTkImage(light_image=img, dark_image=img, size=size)
        self._video_label.configure(image=self._photo, text="")

    # ------------------------------------------------------------------
    # Ações da UI
    # ------------------------------------------------------------------
    def _recognize(self) -> None:
        """Reconhece manualmente a expressão atual."""
        recognition = self._engine.recognize()
        self._show_recognition(recognition)

    def _show_recognition(self, recognition) -> None:
        """Atualiza a UI com o resultado do reconhecimento."""
        parsed = recognition.parsed
        self._expr_var.set(parsed.cleaned or parsed.raw or "—")

        steps_text = ""
        if recognition.evaluation and recognition.evaluation.success:
            self._result_var.set(recognition.evaluation.result)
            steps_text = "\n".join(recognition.evaluation.steps)
        elif not parsed.is_valid:
            self._result_var.set("inválida")
            steps_text = parsed.error
        else:
            self._result_var.set("—")
            if recognition.evaluation:
                steps_text = recognition.evaluation.error

        self._steps_box.configure(state="normal")
        self._steps_box.delete("1.0", "end")
        self._steps_box.insert("1.0", steps_text or "—")
        self._steps_box.configure(state="disabled")

    def _clear(self) -> None:
        """Limpa o canvas e os campos."""
        self._engine.clear_canvas()
        self._expr_var.set("—")
        self._result_var.set("—")

    def _load_model(self) -> None:
        """Recarrega o modelo do disco."""
        ok = self._engine.reload_model()
        self._update_model_status()
        msg = "Modelo carregado." if ok else "Modelo não encontrado."
        logger.info(msg)

    def _train_model(self) -> None:
        """Dispara o treinamento em uma thread separada."""
        self._train_btn.configure(state="disabled", text="🧠 Treinando...")

        def _worker() -> None:
            try:
                from src.ml.trainer import Trainer

                Trainer(self._config.train, self._config.model_path).train()
                self._engine.reload_model()
                self.after(0, lambda: self._model_status.configure(
                    text="Treino concluído e modelo carregado."
                ))
            except Exception as exc:  # noqa: BLE001
                logger.error("Erro no treinamento: %s", exc)
                self.after(0, lambda: self._model_status.configure(
                    text=f"Erro no treino: {exc}"
                ))
            finally:
                self.after(0, lambda: self._train_btn.configure(
                    state="normal", text="🧠 Treinar modelo"
                ))
                self.after(0, self._update_model_status)

        threading.Thread(target=_worker, daemon=True).start()

    def _save_sample(self) -> None:
        """Salva o canvas atual como amostra rotulada."""
        canvas_img = self._engine.get_canvas_image()
        if canvas_img is None:
            self._dataset_status.configure(text="Nada para salvar.")
            return
        from src.preprocessing.image_processor import ImageProcessor

        processor = ImageProcessor(self._config.preprocess)
        normalized = processor.preprocess_single(canvas_img)
        label = self._current_label()
        try:
            self._dataset.save_sample(label, normalized)
            counts = self._dataset.count_per_class()
            self._dataset_status.configure(
                text=f"Salvo '{label}'. Total: {counts.get(label, 0)}"
            )
        except ValueError as exc:
            self._dataset_status.configure(text=str(exc))
        self._engine.clear_canvas()

    # ------------------------------------------------------------------
    # Callbacks de configuração
    # ------------------------------------------------------------------
    def _on_label_change(self, _value: str) -> None:
        """Atualiza o rótulo selecionado."""

    def _current_label(self) -> str:
        """Extrai o nome da classe a partir do item do menu."""
        return self._label_menu.get().split("  ")[0]

    def _on_thickness(self, value: float) -> None:
        """Ajusta a espessura do pincel no canvas em tempo real."""
        if self._engine._canvas is not None:  # noqa: SLF001
            self._engine._canvas.set_thickness(int(value))  # noqa: SLF001

    def _update_model_status(self) -> None:
        """Atualiza o rótulo de status do modelo."""
        if self._engine.predictor.is_loaded:
            self._model_status.configure(text="✅ Modelo carregado.")
        else:
            self._model_status.configure(text="⚠️ Sem modelo (treine ou carregue).")

    # ------------------------------------------------------------------
    # Encerramento
    # ------------------------------------------------------------------
    def _on_close(self) -> None:
        """Encerra o engine e fecha a janela."""
        self._running = False
        try:
            self._engine.stop()
        finally:
            self.destroy()


def launch_gui(config: AppConfig) -> None:
    """Inicia a aplicação gráfica."""
    app = AirMathApp(config)
    app.mainloop()
