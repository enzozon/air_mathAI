"""
Módulo de avaliação matemática.

Avalia expressões com segurança usando SymPy (evitando ``eval``), retornando
o resultado e, quando possível, um passo a passo simplificado da resolução.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import sympy as sp
from sympy.parsing.sympy_parser import (
    parse_expr,
    standard_transformations,
)

from src.utils.logger import get_logger

logger = get_logger(__name__)

_TRANSFORMATIONS = standard_transformations


@dataclass(frozen=True)
class EvaluationResult:
    """Resultado da avaliação de uma expressão."""

    expression: str            # expressão avaliada
    success: bool              # avaliação bem-sucedida?
    result: str = ""           # resultado formatado
    steps: list[str] = field(default_factory=list)  # passos da resolução
    error: str = ""            # mensagem de erro, se houver


class MathEvaluator:
    """Avalia expressões matemáticas com SymPy."""

    def evaluate(self, expression: str, show_steps: bool = True) -> EvaluationResult:
        """Avalia a expressão de forma segura.

        Args:
            expression: Expressão como string (ex.: ``"12+34/2"``).
            show_steps: Se deve gerar um passo a passo simplificado.

        Returns:
            :class:`EvaluationResult` com o resultado ou o erro.
        """
        if not expression.strip():
            return EvaluationResult(expression, success=False, error="Expressão vazia.")

        try:
            # parse_expr com avaliação desativada para inspeção e passos.
            parsed = parse_expr(
                expression,
                transformations=_TRANSFORMATIONS,
                evaluate=False,
            )
            simplified = sp.simplify(parsed)
            numeric = sp.N(simplified)

            result_str = self._format(simplified, numeric)
            steps = self._build_steps(expression, parsed, simplified, numeric) if show_steps else []

            logger.info("Avaliação OK: %s = %s", expression, result_str)
            return EvaluationResult(
                expression=expression,
                success=True,
                result=result_str,
                steps=steps,
            )
        except (sp.SympifyError, SyntaxError, TypeError, ValueError, ZeroDivisionError) as exc:
            logger.warning("Falha ao avaliar %r: %s", expression, exc)
            return EvaluationResult(
                expression=expression,
                success=False,
                error=f"Não foi possível avaliar: {exc}",
            )

    # ------------------------------------------------------------------
    # Formatação e passos
    # ------------------------------------------------------------------
    @staticmethod
    def _format(simplified: sp.Expr, numeric: sp.Expr) -> str:
        """Formata o resultado, preferindo inteiros e decimais legíveis."""
        try:
            value = float(numeric)
        except (TypeError, ValueError):
            return str(simplified)

        if value.is_integer():
            return str(int(value))
        return f"{value:.6g}"

    @staticmethod
    def _build_steps(
        original: str,
        parsed: sp.Expr,
        simplified: sp.Expr,
        numeric: sp.Expr,
    ) -> list[str]:
        """Monta um passo a passo simples e legível da resolução."""
        steps: list[str] = [f"Expressão: {original}"]

        pretty_parsed = sp.sstr(parsed)
        if pretty_parsed != original:
            steps.append(f"Interpretação: {pretty_parsed}")

        pretty_simpl = sp.sstr(simplified)
        if pretty_simpl != pretty_parsed:
            steps.append(f"Simplificação: {pretty_simpl}")

        try:
            value = float(numeric)
            final = str(int(value)) if value.is_integer() else f"{value:.6g}"
            steps.append(f"Resultado: {final}")
        except (TypeError, ValueError):
            steps.append(f"Resultado: {simplified}")

        return steps
