"""
Módulo do canvas de desenho.

Mantém uma camada transparente sobreposta ao vídeo da webcam, na qual o
usuário desenha seguindo a ponta do dedo indicador. Suporta traços suaves,
controle de espessura e composição com o frame da câmera.
"""
from __future__ import annotations

from typing import Optional

import cv2
import numpy as np

from config import CanvasConfig
from src.utils.logger import get_logger

logger = get_logger(__name__)


class DrawingCanvas:
    """Canvas de desenho sobreposto ao vídeo."""

    def __init__(self, width: int, height: int, config: CanvasConfig) -> None:
        self._width = width
        self._height = height
        self._config = config
        # Camada de desenho em BGR (preto = transparente na composição).
        self._canvas: np.ndarray = np.zeros((height, width, 3), dtype=np.uint8)
        self._prev_point: Optional[tuple[int, int]] = None
        self._smooth_point: Optional[tuple[float, float]] = None
        self._thickness = config.brush_thickness

    # ------------------------------------------------------------------
    # Desenho
    # ------------------------------------------------------------------
    def draw_to(self, point: tuple[int, int]) -> None:
        """Adiciona um segmento de traço até o ponto informado.

        Aplica suavização exponencial para reduzir tremores da mão.

        Args:
            point: Coordenada (x, y) da ponta do dedo indicador.
        """
        smoothed = self._smooth(point)

        if self._prev_point is not None:
            cv2.line(
                self._canvas,
                self._prev_point,
                smoothed,
                self._config.brush_color,
                self._thickness,
                lineType=cv2.LINE_AA,
            )
        self._prev_point = smoothed

    def stop_drawing(self) -> None:
        """Encerra o traço atual (chamado quando o gesto deixa de ser DRAW)."""
        self._prev_point = None
        self._smooth_point = None

    def _smooth(self, point: tuple[int, int]) -> tuple[int, int]:
        """Suaviza o ponto usando média móvel exponencial."""
        alpha = self._config.smoothing
        if self._smooth_point is None or alpha <= 0:
            self._smooth_point = (float(point[0]), float(point[1]))
        else:
            sx = alpha * point[0] + (1 - alpha) * self._smooth_point[0]
            sy = alpha * point[1] + (1 - alpha) * self._smooth_point[1]
            self._smooth_point = (sx, sy)
        return int(self._smooth_point[0]), int(self._smooth_point[1])

    # ------------------------------------------------------------------
    # Controle
    # ------------------------------------------------------------------
    def clear(self) -> None:
        """Limpa todo o canvas."""
        self._canvas[:] = 0
        self.stop_drawing()
        logger.info("Canvas limpo.")

    def set_thickness(self, thickness: int) -> None:
        """Define a espessura do pincel (mínimo 1)."""
        self._thickness = max(1, int(thickness))

    @property
    def thickness(self) -> int:
        """Espessura atual do pincel."""
        return self._thickness

    @property
    def is_empty(self) -> bool:
        """Indica se nada foi desenhado ainda."""
        return not bool(self._canvas.any())

    @property
    def image(self) -> np.ndarray:
        """Cópia da camada de desenho em BGR."""
        return self._canvas.copy()

    # ------------------------------------------------------------------
    # Composição
    # ------------------------------------------------------------------
    def overlay(
        self,
        frame: np.ndarray,
        cursor: Optional[tuple[int, int]] = None,
        show_cursor: bool = False,
    ) -> np.ndarray:
        """Compõe o canvas sobre o frame da webcam.

        Args:
            frame: Frame BGR da webcam.
            cursor: Posição do cursor virtual (ponta do indicador).
            show_cursor: Se deve desenhar o cursor virtual.

        Returns:
            Frame resultante com o desenho sobreposto.
        """
        gray = cv2.cvtColor(self._canvas, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(gray, 5, 255, cv2.THRESH_BINARY)
        mask_inv = cv2.bitwise_not(mask)

        background = cv2.bitwise_and(frame, frame, mask=mask_inv)
        foreground = cv2.bitwise_and(self._canvas, self._canvas, mask=mask)
        composed = cv2.add(background, foreground)

        if show_cursor and cursor is not None:
            cv2.circle(
                composed,
                cursor,
                self._config.cursor_radius,
                self._config.cursor_color,
                cv2.FILLED,
            )
        return composed
