"""
Módulo de reconhecimento de gestos.

Conta quantos dedos estão levantados a partir dos landmarks da mão e
mapeia a contagem para uma ação da aplicação, com estabilização e cooldown.
"""
from __future__ import annotations

import time
from enum import Enum

from config import GestureConfig
from src.tracking.hand_tracker import (
    FINGER_PIPS,
    FINGER_TIPS,
    HandData,
)
from src.utils.logger import get_logger

logger = get_logger(__name__)


class Gesture(Enum):
    """Gestos suportados pela aplicação, mapeados pela contagem de dedos."""

    NONE = 0          # nenhum dedo / mão não detectada
    MOVE = 1          # 1 dedo  -> mover cursor
    DRAW = 2          # 2 dedos -> desenhar
    CLEAR = 3         # 3 dedos -> limpar canvas
    CAPTURE = 4       # 4 dedos -> capturar e reconhecer
    QUIT = 5          # 5 dedos -> encerrar


# Gestos que representam ações pontuais (precisam de cooldown).
ACTION_GESTURES = {Gesture.CLEAR, Gesture.CAPTURE, Gesture.QUIT}


def count_fingers(hand: HandData) -> int:
    """Conta o número de dedos levantados.

    A lógica para os quatro dedos (indicador, médio, anelar, mínimo) compara
    a posição vertical da ponta com a articulação intermediária (PIP).
    Para o polegar, compara a posição horizontal, levando em conta a
    lateralidade da mão.

    Args:
        hand: Dados da mão detectada.

    Returns:
        Quantidade de dedos levantados (0 a 5).
    """
    fingers_up = 0
    lm = hand.landmarks

    # Polegar: depende se a mão é esquerda ou direita.
    thumb_tip = lm[FINGER_TIPS[0]]
    thumb_ip = lm[FINGER_PIPS[0]]
    if hand.handedness == "Right":
        if thumb_tip.x < thumb_ip.x:
            fingers_up += 1
    else:  # Left
        if thumb_tip.x > thumb_ip.x:
            fingers_up += 1

    # Demais dedos: ponta acima (y menor) da articulação PIP -> levantado.
    for tip_idx, pip_idx in zip(FINGER_TIPS[1:], FINGER_PIPS[1:]):
        if lm[tip_idx].y < lm[pip_idx].y:
            fingers_up += 1

    return fingers_up


class GestureRecognizer:
    """Reconhece gestos de forma estável, evitando disparos repetidos."""

    def __init__(self, config: GestureConfig) -> None:
        self._config = config
        self._last_raw_gesture: Gesture = Gesture.NONE
        self._stable_count: int = 0
        self._current_gesture: Gesture = Gesture.NONE
        self._last_action_time: float = 0.0

    def update(self, hand: HandData | None) -> Gesture:
        """Atualiza o estado interno com a mão atual e retorna o gesto contínuo.

        Args:
            hand: Mão detectada ou ``None``.

        Returns:
            O gesto contínuo estável (MOVE, DRAW, etc.).
        """
        if hand is None:
            self._last_raw_gesture = Gesture.NONE
            self._stable_count = 0
            self._current_gesture = Gesture.NONE
            return Gesture.NONE

        raw = Gesture(min(count_fingers(hand), 5))

        if raw == self._last_raw_gesture:
            self._stable_count += 1
        else:
            self._stable_count = 0
            self._last_raw_gesture = raw

        if self._stable_count >= self._config.stability_frames:
            self._current_gesture = raw

        return self._current_gesture

    def consume_action(self) -> Gesture | None:
        """Retorna um gesto de ação se ele deve ser disparado agora.

        Aplica cooldown para que gestos como CLEAR, CAPTURE e QUIT não
        disparem repetidamente enquanto a mão permanece na mesma pose.

        Returns:
            O gesto de ação a ser executado, ou ``None``.
        """
        gesture = self._current_gesture
        if gesture not in ACTION_GESTURES:
            return None

        now = time.monotonic()
        if now - self._last_action_time < self._config.action_cooldown:
            return None

        self._last_action_time = now
        logger.debug("Ação disparada: %s", gesture.name)
        return gesture

    @property
    def current(self) -> Gesture:
        """Gesto contínuo atual."""
        return self._current_gesture
