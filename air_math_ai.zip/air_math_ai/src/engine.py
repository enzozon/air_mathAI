"""
Motor central do Air Math AI.

Orquestra captura, rastreamento, gestos, canvas, pré-processamento e
reconhecimento, expondo uma API simples consumida tanto pela versão de
linha de comando (``main.py``) quanto pela interface gráfica.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

import cv2
import numpy as np

from config import AppConfig, CAPTURES_DIR
from src.canvas.drawing_canvas import DrawingCanvas
from src.capture.video_capture import VideoCapture
from src.gestures.gesture_recognizer import Gesture, GestureRecognizer
from src.math_eval.evaluator import EvaluationResult, MathEvaluator
from src.ml.predictor import ModelNotLoadedError, Predictor
from src.parser.expression_parser import ExpressionParser, ParsedExpression
from src.preprocessing.image_processor import ImageProcessor
from src.tracking.hand_tracker import HandTracker, INDEX_TIP
from src.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class RecognitionResult:
    """Agrega o resultado completo de uma captura."""

    parsed: ParsedExpression
    evaluation: Optional[EvaluationResult]
    num_symbols: int


@dataclass
class FrameResult:
    """Saída de um ciclo de processamento de frame."""

    frame: np.ndarray              # frame composto pronto para exibição
    gesture: Gesture              # gesto contínuo detectado
    action: Optional[Gesture]     # ação pontual disparada neste frame
    recognition: Optional[RecognitionResult] = None  # resultado se houve CAPTURE


class AirMathEngine:
    """Encadeia todos os componentes do pipeline de reconhecimento aéreo."""

    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._capture = VideoCapture(config.camera)
        self._tracker = HandTracker(config.hand)
        self._gestures = GestureRecognizer(config.gesture)
        self._processor = ImageProcessor(config.preprocess)
        self._parser = ExpressionParser()
        self._evaluator = MathEvaluator()
        self._predictor = Predictor(config.model_path)

        self._canvas: Optional[DrawingCanvas] = None
        self._last_recognition: Optional[RecognitionResult] = None

    # ------------------------------------------------------------------
    # Ciclo de vida
    # ------------------------------------------------------------------
    def start(self) -> None:
        """Abre a webcam e tenta carregar o modelo."""
        self._capture.open()
        self._predictor.load()

    def stop(self) -> None:
        """Libera todos os recursos."""
        self._capture.release()
        self._tracker.close()
        logger.info("Engine finalizado.")

    @property
    def predictor(self) -> Predictor:
        """Acesso ao preditor (para recarregar modelo após treino)."""
        return self._predictor

    def reload_model(self) -> bool:
        """Recarrega o modelo do disco. Retorna True em caso de sucesso."""
        return self._predictor.load()

    # ------------------------------------------------------------------
    # Processamento de frame
    # ------------------------------------------------------------------
    def process_frame(self) -> FrameResult:
        """Lê e processa um frame, atualizando o canvas conforme o gesto.

        Returns:
            :class:`FrameResult` com o frame composto e o estado dos gestos.
        """
        frame = self._capture.read()
        height, width = frame.shape[:2]

        if self._canvas is None:
            self._canvas = DrawingCanvas(width, height, self._config.canvas)

        hand = self._tracker.process(frame)
        gesture = self._gestures.update(hand)

        cursor: Optional[tuple[int, int]] = None
        if hand is not None:
            cursor = hand.point(INDEX_TIP)
            self._tracker.draw(frame, hand)

        # Comportamento contínuo por gesto.
        if gesture == Gesture.DRAW and cursor is not None:
            self._canvas.draw_to(cursor)
        else:
            self._canvas.stop_drawing()

        # Ações pontuais (com cooldown).
        action = self._gestures.consume_action()
        recognition: Optional[RecognitionResult] = None

        if action == Gesture.CLEAR:
            self._canvas.clear()
        elif action == Gesture.CAPTURE:
            recognition = self.recognize()
            self._last_recognition = recognition

        show_cursor = gesture in (Gesture.MOVE, Gesture.DRAW)
        composed = self._canvas.overlay(frame, cursor, show_cursor=show_cursor)

        return FrameResult(
            frame=composed,
            gesture=gesture,
            action=action,
            recognition=recognition,
        )

    # ------------------------------------------------------------------
    # Reconhecimento
    # ------------------------------------------------------------------
    def recognize(self, save_capture: bool = True) -> RecognitionResult:
        """Processa o canvas atual e reconhece a expressão desenhada.

        Args:
            save_capture: Se deve salvar a imagem capturada em disco.

        Returns:
            :class:`RecognitionResult` com expressão e avaliação.
        """
        if self._canvas is None or self._canvas.is_empty:
            empty = ParsedExpression(raw="", cleaned="", is_valid=False, error="Canvas vazio.")
            return RecognitionResult(parsed=empty, evaluation=None, num_symbols=0)

        canvas_img = self._canvas.image
        if save_capture:
            self._save_capture(canvas_img)

        symbols = self._processor.segment_expression(canvas_img)
        if not symbols:
            empty = ParsedExpression(
                raw="", cleaned="", is_valid=False, error="Nenhum símbolo detectado."
            )
            return RecognitionResult(parsed=empty, evaluation=None, num_symbols=0)

        try:
            predictions = self._predictor.predict_symbols(symbols)
        except ModelNotLoadedError as exc:
            err = ParsedExpression(raw="", cleaned="", is_valid=False, error=str(exc))
            return RecognitionResult(parsed=err, evaluation=None, num_symbols=len(symbols))

        parsed = self._parser.build(predictions)
        evaluation: Optional[EvaluationResult] = None
        if parsed.is_valid:
            evaluation = self._evaluator.evaluate(parsed.cleaned, show_steps=True)

        return RecognitionResult(
            parsed=parsed,
            evaluation=evaluation,
            num_symbols=len(symbols),
        )

    def clear_canvas(self) -> None:
        """Limpa o canvas via chamada externa (ex.: botão da UI)."""
        if self._canvas is not None:
            self._canvas.clear()

    def get_canvas_image(self) -> Optional[np.ndarray]:
        """Retorna a imagem atual do canvas, se existir."""
        return None if self._canvas is None else self._canvas.image

    @property
    def last_recognition(self) -> Optional[RecognitionResult]:
        """Último resultado de reconhecimento."""
        return self._last_recognition

    # ------------------------------------------------------------------
    # Auxiliares
    # ------------------------------------------------------------------
    @staticmethod
    def _save_capture(image: np.ndarray) -> None:
        """Salva a captura do canvas com timestamp."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = CAPTURES_DIR / f"capture_{timestamp}.png"
        try:
            cv2.imwrite(str(path), image)
            logger.info("Captura salva em %s", path)
        except cv2.error as exc:
            logger.warning("Falha ao salvar captura: %s", exc)
