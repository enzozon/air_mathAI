"""
Módulo de montagem e validação de expressões.

Recebe as predições de símbolos (já ordenadas pela posição horizontal),
monta a string da expressão matemática, aplica correções heurísticas e
valida a sintaxe antes da avaliação.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from src.ml.predictor import Prediction
from src.utils.logger import get_logger

logger = get_logger(__name__)

# Caracteres válidos na expressão final.
_VALID_CHARS = set("0123456789+-*/().")
_OPERATORS = set("+-*/")


@dataclass(frozen=True)
class ParsedExpression:
    """Resultado da montagem da expressão."""

    raw: str            # expressão como reconhecida
    cleaned: str        # expressão após correções heurísticas
    is_valid: bool      # passou na validação de sintaxe?
    error: str = ""     # mensagem de erro, se inválida


class ExpressionParser:
    """Monta e valida expressões matemáticas a partir de predições."""

    def build(self, predictions: list[Prediction]) -> ParsedExpression:
        """Constrói uma :class:`ParsedExpression` a partir das predições.

        Args:
            predictions: Predições ordenadas da esquerda para a direita.

        Returns:
            A expressão montada, limpa e validada.
        """
        ordered = sorted(predictions, key=lambda p: p.center_x)
        raw = "".join(p.symbol for p in ordered)
        cleaned = self._clean(raw)
        is_valid, error = self._validate(cleaned)
        logger.info("Expressão: raw=%r cleaned=%r válida=%s", raw, cleaned, is_valid)
        return ParsedExpression(raw=raw, cleaned=cleaned, is_valid=is_valid, error=error)

    # ------------------------------------------------------------------
    # Limpeza heurística
    # ------------------------------------------------------------------
    @staticmethod
    def _clean(expr: str) -> str:
        """Aplica correções comuns de reconhecimento.

        - remove caracteres inválidos;
        - colapsa operadores duplicados (ex.: ``++`` -> ``+``), preservando
          o sinal negativo unário;
        - remove operadores nas extremidades quando inadequados.
        """
        expr = "".join(ch for ch in expr if ch in _VALID_CHARS)

        # Colapsa sequências de operadores mantendo regra de sinal simples.
        expr = re.sub(r"[*/]{2,}", lambda m: m.group(0)[-1], expr)
        expr = re.sub(r"\++", "+", expr)
        expr = re.sub(r"-{2,}", "-", expr)

        # Remove operador binário no início (exceto '-' e '(').
        expr = re.sub(r"^[*/+]+", "", expr)
        # Remove operadores no final.
        expr = re.sub(r"[+\-*/]+$", "", expr)
        return expr

    # ------------------------------------------------------------------
    # Validação
    # ------------------------------------------------------------------
    @staticmethod
    def _validate(expr: str) -> tuple[bool, str]:
        """Valida a sintaxe básica da expressão.

        Returns:
            ``(is_valid, error)``.
        """
        if not expr:
            return False, "Expressão vazia."

        if any(ch not in _VALID_CHARS for ch in expr):
            return False, "Contém caracteres inválidos."

        # Parênteses balanceados.
        depth = 0
        for ch in expr:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth < 0:
                    return False, "Parênteses desbalanceados."
        if depth != 0:
            return False, "Parênteses desbalanceados."

        # Dois operadores binários seguidos (permitindo unário após operador).
        if re.search(r"[*/][*/]", expr):
            return False, "Operadores consecutivos inválidos."

        # Ponto decimal mal formado.
        if re.search(r"\.\D", expr.replace(".", ".", 1)) and ".." in expr:
            return False, "Ponto decimal inválido."
        if ".." in expr:
            return False, "Ponto decimal inválido."

        return True, ""
