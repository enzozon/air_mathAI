"""
Módulo de pré-processamento de imagem.

Converte o desenho do canvas em entradas adequadas para a CNN:
- escala de cinza;
- binarização (threshold);
- remoção de ruído;
- detecção e recorte da região desenhada;
- centralização;
- redimensionamento para o tamanho esperado pelo modelo.

Também oferece segmentação por contornos para separar múltiplos símbolos
de uma expressão completa, ordenando-os pela posição horizontal.
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from config import PreprocessConfig
from src.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True)
class Symbol:
    """Um símbolo segmentado, com sua imagem e bounding box."""

    image: np.ndarray            # imagem (target_size x target_size), float32 [0,1]
    x: int                       # posição x (canto) da caixa original
    y: int
    w: int
    h: int

    @property
    def center_x(self) -> int:
        """Centro horizontal da caixa, usado para ordenação."""
        return self.x + self.w // 2


class ImageProcessor:
    """Pré-processa o desenho e segmenta símbolos."""

    def __init__(self, config: PreprocessConfig) -> None:
        self._config = config

    # ------------------------------------------------------------------
    # Binarização
    # ------------------------------------------------------------------
    def to_binary(self, canvas_bgr: np.ndarray) -> np.ndarray:
        """Converte o desenho em imagem binária (símbolo branco, fundo preto).

        Args:
            canvas_bgr: Imagem do canvas em BGR.

        Returns:
            Imagem binária ``uint8`` (0 ou 255).
        """
        gray = cv2.cvtColor(canvas_bgr, cv2.COLOR_BGR2GRAY)
        # O canvas já tem traços claros sobre fundo preto; um threshold
        # adaptativo deixa o pipeline robusto a variações de intensidade.
        binary = cv2.adaptiveThreshold(
            gray,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            self._config.threshold_block_size | 1,  # garante ímpar
            -self._config.threshold_c,
        )
        # Remove ruído pontual.
        kernel = np.ones((3, 3), np.uint8)
        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=1)
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=1)
        return binary

    # ------------------------------------------------------------------
    # Normalização de um único símbolo
    # ------------------------------------------------------------------
    def normalize_symbol(self, binary: np.ndarray) -> np.ndarray:
        """Recorta, centraliza e redimensiona um símbolo binário.

        Args:
            binary: Imagem binária contendo um único símbolo.

        Returns:
            Imagem ``float32`` normalizada em [0, 1], no tamanho alvo.
        """
        coords = cv2.findNonZero(binary)
        size = self._config.target_size

        if coords is None:
            return np.zeros((size, size), dtype=np.float32)

        x, y, w, h = cv2.boundingRect(coords)
        cropped = binary[y : y + h, x : x + w]

        # Mantém a proporção encaixando em um quadrado.
        side = max(w, h) + 2 * self._config.padding
        square = np.zeros((side, side), dtype=np.uint8)
        off_x = (side - w) // 2
        off_y = (side - h) // 2
        square[off_y : off_y + h, off_x : off_x + w] = cropped

        resized = cv2.resize(square, (size, size), interpolation=cv2.INTER_AREA)
        return resized.astype(np.float32) / 255.0

    def preprocess_single(self, canvas_bgr: np.ndarray) -> np.ndarray:
        """Pipeline completo para reconhecer um único dígito/símbolo."""
        binary = self.to_binary(canvas_bgr)
        return self.normalize_symbol(binary)

    # ------------------------------------------------------------------
    # Segmentação de expressão (vários símbolos)
    # ------------------------------------------------------------------
    def segment_expression(self, canvas_bgr: np.ndarray) -> list[Symbol]:
        """Segmenta uma expressão em símbolos individuais ordenados.

        Detecta contornos externos, filtra por área mínima, normaliza cada
        recorte e ordena pela posição horizontal (esquerda para a direita).

        Args:
            canvas_bgr: Imagem do canvas em BGR.

        Returns:
            Lista de :class:`Symbol` ordenada da esquerda para a direita.
        """
        binary = self.to_binary(canvas_bgr)
        contours, _ = cv2.findContours(
            binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        boxes: list[tuple[int, int, int, int]] = []
        for contour in contours:
            if cv2.contourArea(contour) < self._config.min_contour_area:
                continue
            boxes.append(cv2.boundingRect(contour))

        boxes = self._merge_overlapping(boxes)
        boxes.sort(key=lambda b: b[0])  # ordena por x (esquerda -> direita)

        symbols: list[Symbol] = []
        pad = self._config.padding
        for x, y, w, h in boxes:
            x0 = max(0, x - pad)
            y0 = max(0, y - pad)
            x1 = min(binary.shape[1], x + w + pad)
            y1 = min(binary.shape[0], y + h + pad)
            roi = binary[y0:y1, x0:x1]
            normalized = self.normalize_symbol(roi)
            symbols.append(Symbol(image=normalized, x=x, y=y, w=w, h=h))

        logger.info("Símbolos segmentados: %d", len(symbols))
        return symbols

    @staticmethod
    def _merge_overlapping(
        boxes: list[tuple[int, int, int, int]],
    ) -> list[tuple[int, int, int, int]]:
        """Mescla caixas que se sobrepõem horizontalmente (ex.: '=' ou 'i').

        Evita que partes de um mesmo símbolo sejam tratadas como símbolos
        distintos. Heurística simples baseada em sobreposição horizontal.
        """
        if not boxes:
            return []

        boxes = sorted(boxes, key=lambda b: b[0])
        merged: list[list[int]] = [list(boxes[0])]

        for x, y, w, h in boxes[1:]:
            lx, ly, lw, lh = merged[-1]
            # Sobreposição horizontal significativa -> mesclar.
            overlap = min(lx + lw, x + w) - max(lx, x)
            if overlap > 0.4 * min(lw, w):
                nx = min(lx, x)
                ny = min(ly, y)
                nx2 = max(lx + lw, x + w)
                ny2 = max(ly + lh, y + h)
                merged[-1] = [nx, ny, nx2 - nx, ny2 - ny]
            else:
                merged.append([x, y, w, h])

        return [tuple(b) for b in merged]  # type: ignore[misc]
