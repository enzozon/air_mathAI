"""
Módulo de rastreamento de mãos.

Usa o MediaPipe Hands para detectar a mão e extrair os 21 landmarks.
Fornece estruturas de dados convenientes e utilitários de desenho.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import cv2
import mediapipe as mp
import numpy as np

from config import HandConfig
from src.utils.logger import get_logger

logger = get_logger(__name__)


# Índices dos landmarks de interesse (MediaPipe Hands).
WRIST = 0
THUMB_TIP = 4
INDEX_TIP = 8
MIDDLE_TIP = 12
RING_TIP = 16
PINKY_TIP = 20

FINGER_TIPS = (THUMB_TIP, INDEX_TIP, MIDDLE_TIP, RING_TIP, PINKY_TIP)
FINGER_PIPS = (3, 6, 10, 14, 18)  # articulações intermediárias


@dataclass(frozen=True)
class Landmark:
    """Representa um landmark da mão em coordenadas de pixel e normalizadas."""

    x: int          # pixel x
    y: int          # pixel y
    z: float        # profundidade relativa (MediaPipe)
    norm_x: float   # x normalizado [0, 1]
    norm_y: float   # y normalizado [0, 1]


@dataclass
class HandData:
    """Conjunto completo de informações de uma mão detectada."""

    landmarks: list[Landmark]
    handedness: str          # "Left" ou "Right"
    score: float             # confiança da classificação de lateralidade

    def point(self, index: int) -> tuple[int, int]:
        """Retorna o ponto (x, y) em pixels de um landmark pelo índice."""
        lm = self.landmarks[index]
        return lm.x, lm.y


class HandTracker:
    """Detector e rastreador de mãos baseado no MediaPipe."""

    def __init__(self, config: HandConfig) -> None:
        self._config = config
        self._mp_hands = mp.solutions.hands
        self._mp_draw = mp.solutions.drawing_utils
        self._mp_styles = mp.solutions.drawing_styles
        self._hands = self._mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=config.max_num_hands,
            model_complexity=config.model_complexity,
            min_detection_confidence=config.min_detection_confidence,
            min_tracking_confidence=config.min_tracking_confidence,
        )
        logger.info("MediaPipe Hands inicializado.")

    def process(self, frame_bgr: np.ndarray) -> Optional[HandData]:
        """Processa um frame e retorna os dados da mão principal, se houver.

        Args:
            frame_bgr: Frame no formato BGR (OpenCV).

        Returns:
            :class:`HandData` da primeira mão detectada ou ``None``.
        """
        height, width = frame_bgr.shape[:2]
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        rgb.flags.writeable = False
        results = self._hands.process(rgb)

        if not results.multi_hand_landmarks:
            return None

        hand_landmarks = results.multi_hand_landmarks[0]
        handedness = "Right"
        score = 1.0
        if results.multi_handedness:
            classification = results.multi_handedness[0].classification[0]
            handedness = classification.label
            score = float(classification.score)

        landmarks: list[Landmark] = []
        for lm in hand_landmarks.landmark:
            landmarks.append(
                Landmark(
                    x=int(lm.x * width),
                    y=int(lm.y * height),
                    z=float(lm.z),
                    norm_x=float(lm.x),
                    norm_y=float(lm.y),
                )
            )

        return HandData(landmarks=landmarks, handedness=handedness, score=score)

    def draw(self, frame_bgr: np.ndarray, hand: HandData) -> np.ndarray:
        """Desenha o esqueleto da mão sobre o frame (in-place)."""
        for tip in FINGER_TIPS:
            cv2.circle(frame_bgr, hand.point(tip), 6, (255, 0, 255), cv2.FILLED)
        # Conexões simplificadas dedo a dedo.
        connections = [
            (0, 1, 2, 3, 4),
            (0, 5, 6, 7, 8),
            (0, 9, 10, 11, 12),
            (0, 13, 14, 15, 16),
            (0, 17, 18, 19, 20),
        ]
        for chain in connections:
            for a, b in zip(chain, chain[1:]):
                cv2.line(frame_bgr, hand.point(a), hand.point(b), (180, 180, 180), 2)
        return frame_bgr

    def close(self) -> None:
        """Libera os recursos do MediaPipe."""
        self._hands.close()
        logger.info("MediaPipe Hands finalizado.")

    def __enter__(self) -> "HandTracker":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
