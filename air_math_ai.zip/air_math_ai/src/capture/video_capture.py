"""
Módulo de captura de vídeo.

Encapsula o acesso à webcam via OpenCV, expondo uma interface simples
para obter frames em tempo real e liberar os recursos com segurança.
"""
from __future__ import annotations

from types import TracebackType
from typing import Optional

import cv2
import numpy as np

from config import CameraConfig
from src.utils.logger import get_logger

logger = get_logger(__name__)


class VideoCaptureError(RuntimeError):
    """Erro relacionado à captura de vídeo."""


class VideoCapture:
    """Wrapper de alto nível para :class:`cv2.VideoCapture`.

    Pode ser usado como gerenciador de contexto::

        with VideoCapture(CameraConfig()) as cam:
            frame = cam.read()
    """

    def __init__(self, config: CameraConfig) -> None:
        self._config = config
        self._cap: Optional[cv2.VideoCapture] = None

    def open(self) -> "VideoCapture":
        """Abre a webcam e aplica as configurações desejadas.

        Raises:
            VideoCaptureError: Se a câmera não puder ser aberta.
        """
        logger.info("Abrindo webcam no índice %d...", self._config.index)
        cap = cv2.VideoCapture(self._config.index, cv2.CAP_ANY)
        if not cap.isOpened():
            raise VideoCaptureError(
                f"Não foi possível abrir a webcam (índice {self._config.index}). "
                "Verifique se ela está conectada e não está em uso."
            )

        cap.set(cv2.CAP_PROP_FRAME_WIDTH, self._config.width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._config.height)
        cap.set(cv2.CAP_PROP_FPS, self._config.fps)

        self._cap = cap
        logger.info(
            "Webcam aberta: %dx%d @ %d fps",
            int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
            int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
            int(cap.get(cv2.CAP_PROP_FPS)),
        )
        return self

    def read(self) -> np.ndarray:
        """Lê um frame da webcam.

        Returns:
            Frame BGR como ``np.ndarray``. Espelhado horizontalmente se
            ``flip_horizontal`` estiver ativo.

        Raises:
            VideoCaptureError: Se a câmera não estiver aberta ou a leitura falhar.
        """
        if self._cap is None:
            raise VideoCaptureError("A webcam não foi aberta. Chame open() antes.")

        ok, frame = self._cap.read()
        if not ok or frame is None:
            raise VideoCaptureError("Falha ao ler o frame da webcam.")

        if self._config.flip_horizontal:
            frame = cv2.flip(frame, 1)
        return frame

    @property
    def is_opened(self) -> bool:
        """Indica se a webcam está aberta."""
        return self._cap is not None and self._cap.isOpened()

    def release(self) -> None:
        """Libera os recursos da webcam."""
        if self._cap is not None:
            self._cap.release()
            self._cap = None
            logger.info("Webcam liberada.")

    # ------------------------------------------------------------------
    # Protocolo de gerenciador de contexto
    # ------------------------------------------------------------------
    def __enter__(self) -> "VideoCapture":
        return self.open()

    def __exit__(
        self,
        exc_type: Optional[type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        self.release()
