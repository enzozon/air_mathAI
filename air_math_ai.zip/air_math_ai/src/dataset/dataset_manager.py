"""
Módulo de gerenciamento de dataset.

Permite criar um dataset personalizado a partir da escrita do usuário,
salvando automaticamente imagens rotuladas em pastas por classe, e carregar
esse dataset (ou um dataset externo no mesmo formato) para o treinamento.

Estrutura esperada em disco::

    data/dataset/
        0/   imagem0001.png ...
        1/   ...
        add/ ...
        sub/ ...
        ...
"""
from __future__ import annotations

import time
from pathlib import Path

import cv2
import numpy as np

from config import CLASS_NAMES, DATASET_DIR, PreprocessConfig
from src.utils.logger import get_logger

logger = get_logger(__name__)


class DatasetManager:
    """Cria, organiza e carrega o dataset de símbolos."""

    def __init__(
        self,
        dataset_dir: Path = DATASET_DIR,
        preprocess: PreprocessConfig | None = None,
    ) -> None:
        self._dir = dataset_dir
        self._preprocess = preprocess or PreprocessConfig()
        self._dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Coleta de amostras
    # ------------------------------------------------------------------
    def save_sample(self, label: str, image: np.ndarray) -> Path:
        """Salva uma amostra rotulada no diretório da classe.

        Args:
            label: Nome da classe (deve estar em ``CLASS_NAMES``).
            image: Imagem normalizada (float [0,1]) ou uint8.

        Returns:
            Caminho do arquivo salvo.

        Raises:
            ValueError: Se o rótulo for desconhecido.
        """
        if label not in CLASS_NAMES:
            raise ValueError(
                f"Rótulo desconhecido: {label!r}. Esperado um de {CLASS_NAMES}."
            )

        class_dir = self._dir / label
        class_dir.mkdir(parents=True, exist_ok=True)

        if image.dtype != np.uint8:
            image = (np.clip(image, 0.0, 1.0) * 255).astype(np.uint8)

        filename = f"{label}_{int(time.time() * 1000)}.png"
        path = class_dir / filename
        cv2.imwrite(str(path), image)
        logger.info("Amostra salva: %s", path.name)
        return path

    def count_per_class(self) -> dict[str, int]:
        """Retorna a quantidade de amostras por classe."""
        counts: dict[str, int] = {}
        for label in CLASS_NAMES:
            class_dir = self._dir / label
            if class_dir.exists():
                counts[label] = len(list(class_dir.glob("*.png")))
            else:
                counts[label] = 0
        return counts

    # ------------------------------------------------------------------
    # Carregamento para treinamento
    # ------------------------------------------------------------------
    def load(self) -> tuple[np.ndarray, np.ndarray, list[str]]:
        """Carrega todo o dataset em memória.

        Returns:
            Tupla ``(X, y, class_names)`` onde:
            - ``X`` tem shape ``(N, size, size, 1)`` float32 em [0,1];
            - ``y`` tem shape ``(N,)`` com índices de classe;
            - ``class_names`` é a lista de classes presentes (ordenada).

        Raises:
            FileNotFoundError: Se nenhuma amostra for encontrada.
        """
        size = self._preprocess.target_size
        images: list[np.ndarray] = []
        labels: list[int] = []

        present_classes = [
            c for c in CLASS_NAMES if (self._dir / c).exists()
            and any((self._dir / c).glob("*.png"))
        ]
        if not present_classes:
            raise FileNotFoundError(
                f"Nenhuma amostra encontrada em {self._dir}. "
                "Colete dados ou baixe um dataset compatível."
            )

        class_to_idx = {name: i for i, name in enumerate(present_classes)}

        for class_name in present_classes:
            for img_path in (self._dir / class_name).glob("*.png"):
                img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
                if img is None:
                    logger.warning("Imagem ilegível ignorada: %s", img_path)
                    continue
                if img.shape != (size, size):
                    img = cv2.resize(img, (size, size), interpolation=cv2.INTER_AREA)
                images.append(img.astype(np.float32) / 255.0)
                labels.append(class_to_idx[class_name])

        x = np.expand_dims(np.array(images, dtype=np.float32), axis=-1)
        y = np.array(labels, dtype=np.int64)
        logger.info(
            "Dataset carregado: %d amostras, %d classes.", len(y), len(present_classes)
        )
        return x, y, present_classes
