"""
Pipeline de treinamento da CNN.

Carrega o dataset, divide em treino/validação, aplica data augmentation leve,
treina a CNN, salva o modelo e os rótulos, e gera gráficos das métricas.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from config import (
    DEFAULT_MODEL_PATH,
    LABELS_PATH,
    LOGS_DIR,
    PreprocessConfig,
    TrainConfig,
)
from src.dataset.dataset_manager import DatasetManager
from src.ml.model import build_cnn, compile_model
from src.utils.logger import get_logger

if TYPE_CHECKING:  # pragma: no cover
    import tensorflow as tf

logger = get_logger(__name__)


class Trainer:
    """Orquestra o treinamento end-to-end da CNN."""

    def __init__(
        self,
        config: TrainConfig | None = None,
        model_path: Path = DEFAULT_MODEL_PATH,
    ) -> None:
        self._config = config or TrainConfig()
        self._model_path = model_path
        self._dataset = DatasetManager(
            preprocess=PreprocessConfig(target_size=self._config.image_size)
        )

    def train(self, plot_metrics: bool = True) -> "tf.keras.callbacks.History":
        """Executa o treinamento completo.

        Args:
            plot_metrics: Se deve salvar gráficos de acurácia/perda.

        Returns:
            Histórico de treinamento do Keras.
        """
        import tensorflow as tf

        np.random.seed(self._config.random_seed)
        tf.random.set_seed(self._config.random_seed)

        x, y, class_names = self._dataset.load()
        logger.info("Treinando com %d classes: %s", len(class_names), class_names)

        model = build_cnn(len(class_names), self._config.image_size)
        model = compile_model(model, self._config.learning_rate)
        model.summary(print_fn=logger.info)

        augmentation = tf.keras.Sequential(
            [
                tf.keras.layers.RandomRotation(0.08),
                tf.keras.layers.RandomZoom(0.1),
                tf.keras.layers.RandomTranslation(0.08, 0.08),
            ],
            name="augmentation",
        )

        train_ds, val_ds = self._make_datasets(x, y, augmentation)

        callbacks = [
            tf.keras.callbacks.EarlyStopping(
                monitor="val_loss",
                patience=self._config.early_stopping_patience,
                restore_best_weights=True,
            ),
            tf.keras.callbacks.ReduceLROnPlateau(
                monitor="val_loss", factor=0.5, patience=2, min_lr=1e-5
            ),
        ]

        history = model.fit(
            train_ds,
            validation_data=val_ds,
            epochs=self._config.epochs,
            callbacks=callbacks,
            verbose=2,
        )

        self._save(model, class_names)
        if plot_metrics:
            self._plot(history)
        return history

    # ------------------------------------------------------------------
    # Auxiliares
    # ------------------------------------------------------------------
    def _make_datasets(
        self,
        x: np.ndarray,
        y: np.ndarray,
        augmentation: "tf.keras.Sequential",
    ) -> tuple["tf.data.Dataset", "tf.data.Dataset"]:
        """Cria os datasets de treino e validação com embaralhamento."""
        import tensorflow as tf

        indices = np.arange(len(x))
        np.random.shuffle(indices)
        split = int(len(x) * (1 - self._config.validation_split))
        train_idx, val_idx = indices[:split], indices[split:]

        batch = self._config.batch_size

        train_ds = (
            tf.data.Dataset.from_tensor_slices((x[train_idx], y[train_idx]))
            .shuffle(2048)
            .batch(batch)
            .map(lambda img, lbl: (augmentation(img, training=True), lbl))
            .prefetch(tf.data.AUTOTUNE)
        )
        val_ds = (
            tf.data.Dataset.from_tensor_slices((x[val_idx], y[val_idx]))
            .batch(batch)
            .prefetch(tf.data.AUTOTUNE)
        )
        return train_ds, val_ds

    def _save(self, model: "tf.keras.Model", class_names: list[str]) -> None:
        """Salva o modelo e o mapeamento de rótulos em disco."""
        self._model_path.parent.mkdir(parents=True, exist_ok=True)
        model.save(self._model_path)
        LABELS_PATH.write_text(
            json.dumps(class_names, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        logger.info("Modelo salvo em %s", self._model_path)
        logger.info("Rótulos salvos em %s", LABELS_PATH)

    def _plot(self, history: "tf.keras.callbacks.History") -> None:
        """Gera e salva gráficos de acurácia e perda."""
        try:
            import matplotlib

            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("Matplotlib indisponível; pulando gráficos.")
            return

        hist = history.history
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))

        ax1.plot(hist.get("accuracy", []), label="treino")
        ax1.plot(hist.get("val_accuracy", []), label="validação")
        ax1.set_title("Acurácia")
        ax1.set_xlabel("Época")
        ax1.legend()

        ax2.plot(hist.get("loss", []), label="treino")
        ax2.plot(hist.get("val_loss", []), label="validação")
        ax2.set_title("Perda")
        ax2.set_xlabel("Época")
        ax2.legend()

        out = LOGS_DIR / "training_metrics.png"
        fig.tight_layout()
        fig.savefig(out, dpi=120)
        plt.close(fig)
        logger.info("Gráficos de treinamento salvos em %s", out)
