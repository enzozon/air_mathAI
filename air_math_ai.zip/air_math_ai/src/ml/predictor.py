"""
Módulo de inferência.

Carrega o modelo treinado e os rótulos, e oferece predição de símbolos
individuais e de listas de símbolos segmentados de uma expressão.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import numpy as np

from config import CLASS_LABELS, DEFAULT_MODEL_PATH, LABELS_PATH
from src.preprocessing.image_processor import Symbol
from src.utils.logger import get_logger

if TYPE_CHECKING:  # pragma: no cover
    import tensorflow as tf

logger = get_logger(__name__)


@dataclass(frozen=True)
class Prediction:
    """Resultado da predição de um símbolo."""

    class_name: str       # nome interno da classe (ex.: "add")
    symbol: str           # caractere correspondente (ex.: "+")
    confidence: float     # probabilidade [0, 1]
    center_x: int         # posição horizontal, para ordenação


class ModelNotLoadedError(RuntimeError):
    """Levantado quando a inferência é solicitada sem modelo carregado."""


class Predictor:
    """Encapsula o modelo Keras para inferência de símbolos."""

    def __init__(self, model_path: Path = DEFAULT_MODEL_PATH) -> None:
        self._model_path = model_path
        self._model: Optional["tf.keras.Model"] = None
        self._class_names: list[str] = []

    # ------------------------------------------------------------------
    # Carregamento
    # ------------------------------------------------------------------
    def load(self) -> bool:
        """Carrega o modelo e os rótulos do disco.

        Returns:
            ``True`` se carregado com sucesso, ``False`` caso contrário.
        """
        if not self._model_path.exists():
            logger.warning("Modelo não encontrado em %s.", self._model_path)
            return False
        if not LABELS_PATH.exists():
            logger.warning("Arquivo de rótulos não encontrado em %s.", LABELS_PATH)
            return False

        try:
            import tensorflow as tf

            self._model = tf.keras.models.load_model(self._model_path)
            self._class_names = json.loads(LABELS_PATH.read_text(encoding="utf-8"))
            logger.info(
                "Modelo carregado (%d classes) de %s.",
                len(self._class_names),
                self._model_path,
            )
            return True
        except Exception as exc:  # noqa: BLE001 - reporta qualquer falha de load
            logger.error("Falha ao carregar o modelo: %s", exc)
            self._model = None
            return False

    @property
    def is_loaded(self) -> bool:
        """Indica se há um modelo carregado."""
        return self._model is not None

    # ------------------------------------------------------------------
    # Inferência
    # ------------------------------------------------------------------
    def predict_symbol(self, image: np.ndarray, center_x: int = 0) -> Prediction:
        """Prediz a classe de uma única imagem normalizada.

        Args:
            image: Imagem ``(size, size)`` float em [0, 1].
            center_x: Posição horizontal para ordenação posterior.

        Returns:
            :class:`Prediction` com a classe mais provável.

        Raises:
            ModelNotLoadedError: Se nenhum modelo estiver carregado.
        """
        if self._model is None:
            raise ModelNotLoadedError(
                "Nenhum modelo carregado. Treine ou carregue um modelo primeiro."
            )

        batch = image.reshape(1, image.shape[0], image.shape[1], 1).astype(np.float32)
        probs = self._model.predict(batch, verbose=0)[0]
        idx = int(np.argmax(probs))
        class_name = self._class_names[idx]
        return Prediction(
            class_name=class_name,
            symbol=CLASS_LABELS.get(class_name, "?"),
            confidence=float(probs[idx]),
            center_x=center_x,
        )

    def predict_symbols(self, symbols: list[Symbol]) -> list[Prediction]:
        """Prediz uma lista de símbolos segmentados, preservando a ordem.

        Args:
            symbols: Símbolos já ordenados da esquerda para a direita.

        Returns:
            Lista de predições na mesma ordem de entrada.
        """
        return [self.predict_symbol(s.image, s.center_x) for s in symbols]
