"""
Definição da arquitetura da CNN.

Mantém a criação do modelo desacoplada do treinamento e da inferência,
permitindo trocar a arquitetura sem alterar o restante do sistema.

As importações do TensorFlow são feitas de forma preguiçosa (lazy) para que
os módulos de captura/desenho funcionem mesmo sem o TensorFlow instalado.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    import tensorflow as tf


def build_cnn(num_classes: int, image_size: int = 28) -> "tf.keras.Model":
    """Constrói uma CNN compacta para classificação de símbolos.

    Arquitetura: três blocos convolucionais com BatchNorm e MaxPooling,
    seguidos de camadas densas com dropout. Adequada para imagens 28x28.

    Args:
        num_classes: Número de classes de saída.
        image_size: Lado da imagem quadrada de entrada.

    Returns:
        Modelo Keras ainda não compilado.
    """
    import tensorflow as tf
    from tensorflow.keras import layers, models

    model = models.Sequential(
        [
            layers.Input(shape=(image_size, image_size, 1)),
            layers.Conv2D(32, (3, 3), activation="relu", padding="same"),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),

            layers.Conv2D(64, (3, 3), activation="relu", padding="same"),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),

            layers.Conv2D(128, (3, 3), activation="relu", padding="same"),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),

            layers.Flatten(),
            layers.Dense(128, activation="relu"),
            layers.Dropout(0.4),
            layers.Dense(num_classes, activation="softmax"),
        ],
        name="air_math_cnn",
    )
    return model


def compile_model(model: "tf.keras.Model", learning_rate: float) -> "tf.keras.Model":
    """Compila o modelo com otimizador Adam e perda de entropia cruzada."""
    import tensorflow as tf

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model
