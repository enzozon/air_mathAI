"""Utilitário de logging centralizado para o Air Math AI."""
from __future__ import annotations

import logging
import sys
from pathlib import Path

from config import LOGS_DIR

_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
_DATE_FORMAT = "%H:%M:%S"


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """Cria (ou recupera) um logger configurado.

    Args:
        name: Nome do logger, geralmente ``__name__``.
        level: Nível mínimo de log.

    Returns:
        Instância de :class:`logging.Logger` pronta para uso.
    """
    logger = logging.getLogger(name)
    if logger.handlers:  # já configurado
        return logger

    logger.setLevel(level)
    logger.propagate = False

    formatter = logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT)

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    try:
        file_path: Path = LOGS_DIR / "air_math_ai.log"
        file_handler = logging.FileHandler(file_path, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except OSError:
        # Falha ao abrir arquivo de log não deve quebrar a aplicação.
        logger.warning("Não foi possível criar o arquivo de log em disco.")

    return logger
