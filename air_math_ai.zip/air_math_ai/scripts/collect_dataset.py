"""
Coletor de dataset via webcam (linha de comando).

Permite criar rapidamente um dataset personalizado da sua escrita. Desenhe um
símbolo no ar (2 dedos), pressione a tecla correspondente ao rótulo para salvar
a amostra, e use as teclas para alternar entre as classes.

Uso:
    python scripts/collect_dataset.py

Teclas:
    [s]  salvar a amostra atual com o rótulo selecionado
    [n]  próxima classe        [p]  classe anterior
    [c]  limpar canvas         [q] ou ESC  sair
"""
from __future__ import annotations

import sys
from pathlib import Path

import cv2

# Permite executar a partir da raiz do projeto.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import CLASS_LABELS, CLASS_NAMES, DEFAULT_CONFIG  # noqa: E402
from src.canvas.drawing_canvas import DrawingCanvas  # noqa: E402
from src.capture.video_capture import VideoCapture  # noqa: E402
from src.dataset.dataset_manager import DatasetManager  # noqa: E402
from src.gestures.gesture_recognizer import Gesture, GestureRecognizer  # noqa: E402
from src.preprocessing.image_processor import ImageProcessor  # noqa: E402
from src.tracking.hand_tracker import HandTracker, INDEX_TIP  # noqa: E402


def main() -> None:
    """Loop principal de coleta."""
    cfg = DEFAULT_CONFIG
    dataset = DatasetManager()
    processor = ImageProcessor(cfg.preprocess)
    tracker = HandTracker(cfg.hand)
    recognizer = GestureRecognizer(cfg.gesture)

    label_idx = 0
    canvas: DrawingCanvas | None = None

    with VideoCapture(cfg.camera) as cam:
        while True:
            frame = cam.read()
            h, w = frame.shape[:2]
            if canvas is None:
                canvas = DrawingCanvas(w, h, cfg.canvas)

            hand = tracker.process(frame)
            gesture = recognizer.update(hand)
            cursor = hand.point(INDEX_TIP) if hand else None

            if gesture == Gesture.DRAW and cursor:
                canvas.draw_to(cursor)
            else:
                canvas.stop_drawing()
            if recognizer.consume_action() == Gesture.CLEAR:
                canvas.clear()

            composed = canvas.overlay(frame, cursor, show_cursor=gesture != Gesture.NONE)

            label = CLASS_NAMES[label_idx]
            counts = dataset.count_per_class()
            cv2.putText(
                composed, f"Classe: {label} ({CLASS_LABELS[label]}) | amostras: {counts[label]}",
                (15, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2,
            )
            cv2.putText(
                composed, "[s] salvar  [n/p] classe  [c] limpar  [q] sair",
                (15, 65), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 2,
            )
            cv2.imshow("Coletor de Dataset - Air Math AI", composed)

            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                break
            if key == ord("s") and not canvas.is_empty:
                img = processor.preprocess_single(canvas.image)
                dataset.save_sample(label, img)
                canvas.clear()
            elif key == ord("n"):
                label_idx = (label_idx + 1) % len(CLASS_NAMES)
            elif key == ord("p"):
                label_idx = (label_idx - 1) % len(CLASS_NAMES)
            elif key == ord("c"):
                canvas.clear()

    tracker.close()
    cv2.destroyAllWindows()
    print("Resumo do dataset:")
    for name, count in dataset.count_per_class().items():
        print(f"  {name:6} ({CLASS_LABELS[name]}): {count}")


if __name__ == "__main__":
    main()
