"""
Importador de dataset externo.

Reorganiza um dataset de símbolos matemáticos manuscritos (por exemplo, o
popular "Handwritten Math Symbols" do Kaggle) para a estrutura de pastas
esperada pelo Air Math AI, mapeando nomes de classes para os rótulos internos.

Uso:
    python scripts/prepare_dataset.py --source /caminho/do/dataset_externo

O script copia imagens das pastas de origem para ``data/dataset/<classe>``,
convertendo para escala de cinza 28x28. Apenas as classes mapeadas abaixo
são importadas; ajuste ``FOLDER_MAP`` conforme o dataset de origem.
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

import cv2

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import DATASET_DIR, PreprocessConfig  # noqa: E402

# Mapeia nomes de pastas comuns em datasets externos -> rótulos internos.
FOLDER_MAP: dict[str, str] = {
    "0": "0", "1": "1", "2": "2", "3": "3", "4": "4",
    "5": "5", "6": "6", "7": "7", "8": "8", "9": "9",
    "+": "add", "plus": "add", "add": "add",
    "-": "sub", "minus": "sub", "sub": "sub", "dash": "sub",
    "times": "mul", "*": "mul", "mul": "mul", "x": "mul",
    "div": "div", "/": "div", "slash": "div", "forward_slash": "div",
    "(": "lparen", "lparen": "lparen",
    ")": "rparen", "rparen": "rparen",
    ".": "dot", "dot": "dot", "decimal": "dot",
}


def prepare(source: Path, limit_per_class: int | None) -> None:
    """Importa e converte as imagens do dataset de origem.

    Args:
        source: Diretório raiz com subpastas por classe.
        limit_per_class: Limite opcional de imagens por classe.
    """
    if not source.exists():
        raise FileNotFoundError(f"Diretório de origem não encontrado: {source}")

    size = PreprocessConfig().target_size
    total = 0

    for folder in sorted(source.iterdir()):
        if not folder.is_dir():
            continue
        label = FOLDER_MAP.get(folder.name.lower())
        if label is None:
            print(f"  ignorando pasta não mapeada: {folder.name}")
            continue

        dest = DATASET_DIR / label
        dest.mkdir(parents=True, exist_ok=True)

        images = list(folder.glob("*.png")) + list(folder.glob("*.jpg"))
        if limit_per_class:
            images = images[:limit_per_class]

        for i, img_path in enumerate(images):
            img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue
            img = cv2.resize(img, (size, size), interpolation=cv2.INTER_AREA)
            out = dest / f"{label}_ext_{i:05d}.png"
            cv2.imwrite(str(out), img)
            total += 1
        print(f"  {folder.name} -> {label}: {len(images)} imagens")

    print(f"Importação concluída. {total} imagens em {DATASET_DIR}")


def main() -> None:
    """Analisa argumentos e executa a importação."""
    parser = argparse.ArgumentParser(description="Importar dataset externo")
    parser.add_argument("--source", required=True, type=Path, help="diretório de origem")
    parser.add_argument(
        "--limit", type=int, default=None, help="máximo de imagens por classe"
    )
    args = parser.parse_args()
    prepare(args.source, args.limit)


if __name__ == "__main__":
    main()
