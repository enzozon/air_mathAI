"""
Testes unitários para os módulos de parsing, avaliação e pré-processamento.

Estes testes não dependem de webcam, MediaPipe ou TensorFlow, permitindo
validar a lógica central rapidamente::

    python -m pytest tests/ -v
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pytest

from config import PreprocessConfig
from src.math_eval.evaluator import MathEvaluator
from src.parser.expression_parser import ExpressionParser
from src.preprocessing.image_processor import ImageProcessor


@dataclass
class FakePrediction:
    """Predição falsa para alimentar o parser nos testes."""

    symbol: str
    center_x: int


def _expr(text: str) -> list[FakePrediction]:
    """Cria predições espaçadas a partir de uma string."""
    return [FakePrediction(ch, i * 40) for i, ch in enumerate(text)]


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------
class TestExpressionParser:
    def setup_method(self) -> None:
        self.parser = ExpressionParser()

    def test_simple_expression(self) -> None:
        parsed = self.parser.build(_expr("12+34/2"))
        assert parsed.cleaned == "12+34/2"
        assert parsed.is_valid

    def test_orders_by_position(self) -> None:
        preds = [FakePrediction("3", 120), FakePrediction("1", 0), FakePrediction("+", 60)]
        parsed = self.parser.build(preds)
        assert parsed.cleaned == "1+3"

    def test_removes_trailing_operator(self) -> None:
        parsed = self.parser.build(_expr("5+3+"))
        assert parsed.cleaned == "5+3"

    def test_unbalanced_parentheses(self) -> None:
        parsed = self.parser.build(_expr("(2+3"))
        assert not parsed.is_valid

    def test_empty_is_invalid(self) -> None:
        parsed = self.parser.build([])
        assert not parsed.is_valid


# ---------------------------------------------------------------------------
# Evaluator
# ---------------------------------------------------------------------------
class TestMathEvaluator:
    def setup_method(self) -> None:
        self.ev = MathEvaluator()

    @pytest.mark.parametrize(
        "expr,expected",
        [
            ("12+34/2", "29"),
            ("(2+3)*4", "20"),
            ("7*8-5", "51"),
            ("10/4", "2.5"),
            ("9-3+1", "7"),
        ],
    )
    def test_evaluates_correctly(self, expr: str, expected: str) -> None:
        result = self.ev.evaluate(expr)
        assert result.success
        assert result.result == expected

    def test_generates_steps(self) -> None:
        result = self.ev.evaluate("2+2", show_steps=True)
        assert result.success
        assert len(result.steps) >= 2

    def test_invalid_expression(self) -> None:
        result = self.ev.evaluate("2++")
        assert not result.success


# ---------------------------------------------------------------------------
# Image processor
# ---------------------------------------------------------------------------
class TestImageProcessor:
    def setup_method(self) -> None:
        self.proc = ImageProcessor(PreprocessConfig())

    def test_single_symbol_shape(self) -> None:
        import cv2

        canvas = np.zeros((200, 200, 3), dtype=np.uint8)
        cv2.putText(canvas, "5", (60, 150), cv2.FONT_HERSHEY_SIMPLEX, 4, (0, 255, 0), 10)
        out = self.proc.preprocess_single(canvas)
        assert out.shape == (28, 28)
        assert out.dtype == np.float32
        assert out.max() <= 1.0

    def test_segments_multiple_symbols(self) -> None:
        import cv2

        canvas = np.zeros((300, 600, 3), dtype=np.uint8)
        for i, ch in enumerate("123"):
            cv2.putText(
                canvas, ch, (60 + i * 150, 200),
                cv2.FONT_HERSHEY_SIMPLEX, 4, (0, 255, 0), 12,
            )
        symbols = self.proc.segment_expression(canvas)
        assert len(symbols) == 3
        # Ordenados da esquerda para a direita.
        xs = [s.center_x for s in symbols]
        assert xs == sorted(xs)
